.. cmake-module:: ../../Modules/CheckFortranCompilerFlag.cmake
