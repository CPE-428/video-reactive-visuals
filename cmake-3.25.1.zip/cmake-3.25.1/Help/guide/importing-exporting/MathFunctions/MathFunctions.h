#pragma once

namespace MathFunctions {
double sqrt(double x);
}
